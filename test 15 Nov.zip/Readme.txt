How to use:

ESC = Quit program

	Generator Illustration phase
Q = Move generator to next step
Numpad 123456789 = Move camera in generator 


	Game phase
Numpad 123456789 = move player

T + Y = Test player pathfinding

U + I = Warp player to path and trace path 1 step


L = Toggle targetting mode (change control context to targeting mode so that numpad 123456789 moves recticle)
	Numpad 5 in targeting mode *hard locks* onto target cell or creature (bugged)

Number 123456 = open inventories
	abcdefghi.... explore inventories

C = open player stats]
SHIFT + C = close player stats

Z (doesn't work yet) = select weapon based spell from list
Shift + Z = close said list

F (doesn't work yet) Fire current spell at target location



